<div class="stm-accordion open">
	<div class="accordion-header">
		<?php esc_html_e( 'Certificates', 'masterstudy-lms-learning-management-system-pro' ); ?>
		<i class="fa fa-chevron-down"></i>
	</div>
	<div class="accordion-body">
		<?php require_once STM_LMS_PRO_ADDONS . '/certificate_builder/templates/parts/certificates/main.php'; ?>
	</div>
</div>
